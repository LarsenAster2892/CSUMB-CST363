

INSERT INTO Department VALUES (1, N'TechnicalSales', 27);
INSERT INTO Department VALUES (2, N'ConsumerSales', 31);
INSERT INTO Department VALUES (3, N'Technical', 15);
INSERT INTO Department VALUES (4, N'Marketing', 13);
INSERT INTO Department VALUES (5, N'NationalSales', 24);
INSERT INTO Department VALUES (6, N'Cutomer', 26);
INSERT INTO Department VALUES (7, N'Accounting', 21);
INSERT INTO Department VALUES (8, N'BusinessSales', 30);
INSERT INTO Department VALUES (9, N'Corporate Care', 18);
INSERT INTO Department VALUES (10, N'CorporateSales', 29);
