
INSERT INTO project VALUES (2, 'Oracle Database Development');
INSERT INTO project VALUES (1, 'Computer Hardware installation');
INSERT INTO project VALUES (3, 'Website Development');
INSERT INTO project VALUES (4, 'Mobile Phone App Development');
